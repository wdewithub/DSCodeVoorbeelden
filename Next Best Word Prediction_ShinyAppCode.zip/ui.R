#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)


# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("Coursera Capstone - Predicting the next word with a Katz-Backoff model"),
  
  # Sidebar requesting text input  
  sidebarLayout(
    sidebarPanel(
       textInput("input_sent", "Please type part of a sentence in here (in English)", value="",width="100%"),
       submitButton("Go predict me the next word !")
    ),
    
  # Give back the next word suggestion(s)
    mainPanel(
      tags$style(type="text/css",
                 ".shiny-output-error { visibility: hidden; }",
                 ".shiny-output-error:before { visibility: hidden; }"),
       tableOutput("predicted")   
    )
  )
))

