#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
   
  
    library(tm)
    library(RWeka)
    library(tidyr)
    library(xlsx)
    library(stringr)
    library(dplyr)
    library(ngram)
    library(pryr)


    #Read in the dictionaries: vul de file nog in eens je je dictionary hebt vastgelegd waarmee je wil gaan werken.
    
    dict_1gram <- readRDS("dict1gram_6freq.rds")
    dict_2gram <- readRDS("dict2gram_freq6_optim.rds")
    dict_3gram <- readRDS("dict3gram_freq6_optim.rds")
    
    preprocess_text <- function(which_doc) {
      
      #Remove non-ASCII characters
      docu <- iconv(which_doc, "latin1", "ASCII", sub="")
      
      #put everything to lowercase
      docu <- tolower(docu)
      
      #Remove smileys, # and @ from tweets, remove ======= lines from newsgroup postings
      
      docu <- gsub("http[[:alnum:]]*", " ", docu) #to remove url's, especially in tweets
      docu <- gsub("@[[:alnum:]]*", " ", docu) #to remove @tags in tweets
      docu <- gsub("#[[:alnum:]]*", " ", docu) #to remove hashtags in tweets
      docu <- gsub("www[:alnum:]*", " ", docu) #Remove url's not starting with http
      docu <- gsub("'", "", docu)
      docu <- gsub("\"", " ", docu)
      docu <- gsub(":", " ", docu)
      docu <- gsub("-", " ", docu)
      docu <- gsub("~", " ", docu)
      docu <- gsub("<3", " ", docu) #to remove ball sack from tweets
      docu <- gsub("xx", " ", docu) 
      docu <- gsub("[a-z]*shit[a-z]*", " ", docu) #to remove derived words from shit, esp in tweets
      docu <- gsub("[a-z]*fuck[a-z]*", " ", docu) #to remove derived words from fuck, esp in tweets
      docu <- gsub("+[>]", " ", docu) 
      docu <- gsub("+[-]", " ", docu) #to remove --------- in tweets especially
      docu <- gsub("+[=]", " ", docu) #to remove ========= in newsgroups especially 
      docu <- gsub("[:;(]([-]|[\\+]|[a-z]|[A-Z])?[)(:)]", " ", docu) #to remove smiley stuff from tweets
      docu <- gsub("([a-z]|[A-Z])[:]", " ", docu)
      docu <- gsub("[:]([a-z]|[A-Z])", " ", docu)
      docu <- gsub(" rt ", " ", docu) #to remove retweet indications in tweets
      
      ##Remove numbers and punctuation
      docu <- removePunctuation(removeNumbers(docu))
      
      #Profanity filtering. (source=http://fffff.at/googles-official-list-of-bad-words/)
      google_list <- readRDS("google_bad_words.rds")
      docu <- removeWords(docu, google_list$X1)
      
      ## Stopword removal
      
      docu <- removeWords(docu, stopwords(kind="en"))
      mystopwords <- c("i'd", "lol", "lolol", "oh", "done", "every", "hey", "ah", "yet", "let", "can", "omg", "'s", "'ll", "will", "one", "two", "to", "just", "yes", "no", "ve", "s", "m", "okay", "ok", "let", "bro", "d", "u", "r", "hey", "hehe", "haha", "em", "ya", "ll", "im")
      docu <- removeWords(docu, mystopwords)
      
      ##Remove any extraneous white spaces
      docu <- stripWhitespace(docu)
      
      return(docu)
    }
    
    katz_bo_pred <- function(sentence) {

      ###2. Predict using Katz-backoff model

      ####2.1 Predicting the next word based on the last 3 words

      #####Merge last 3 words with 3gram dictionary
      join_ngramlist <- merge(sentence, dict_3gram, by.x="trigram", by.y="trigram", all.x=TRUE, sort=TRUE)

      if (sum(!is.na(join_ngramlist$freq_4gram)) > 0) {

        #####Discount the observed 4 grams and calculate remaining pmf to pass on for prediction based on last 2 words

        rem_pmf_3grams <- 1-sum((join_ngramlist$freq_4gram-0.5)/join_ngramlist$freq_3gram)

        #####Determine next word prediction based on last 3 words

        join_ngramlist$MLE_4gram <- (join_ngramlist$freq_4gram-0.5)/join_ngramlist$freq_3gram
        join_ngramlist$predword_4gram <- word(join_ngramlist$fourgram,-1)
        trigrampred <- join_ngramlist %>% select(trigram, bigram, unigram, MLE_4gram, predword_4gram)
      } else {
        trigrampred <- join_ngramlist %>% select(trigram, bigram, unigram)
         trigrampred$predword_4gram <- NA
         trigrampred$MLE_4gram <- NA
         rem_pmf_3grams <- 1  #for unobserved trigrams in our dictionary --> rem pmf for bigram estimate is still 1
      }


       ####2.2 Predicting the next word based on the last 2 words

       #####Merge last 2 words with 2gram dictionary

       join_ngramlist <- merge(sentence, dict_2gram, by.x="bigram", by.y="bigram", all.x=TRUE, sort=TRUE)

       if (sum(!is.na(join_ngramlist$freq_3gram)) > 0) {

         #####Discount the observed 3 grams and calculate remaining pmf to pass on for prediction based on last word

         rem_pmf_2grams <- 1-sum((join_ngramlist$freq_3gram-0.5)/join_ngramlist$freq_2gram) #Which pmf is left over after choosing 3gram MLE based on previous 2 words

         #####Calculate which suffix is MLE based on last 2 words

         join_ngramlist$MLE_3gram <- (join_ngramlist$freq_3gram-0.5)/join_ngramlist$freq_2gram * rem_pmf_3grams
         join_ngramlist$predword_3gram <- word(join_ngramlist$trigram.y,-1)
         bigrampred <- join_ngramlist %>% select(bigram, MLE_3gram, predword_3gram)

       } else {
         bigrampred <- join_ngramlist %>% select(bigram)
         bigrampred$MLE_3gram <- NA
         bigrampred$predword_3gram <- NA
         rem_pmf_2grams <- ifelse(rem_pmf_3grams==1, 1, rem_pmf_3grams) #Due to limiting your dictionaries to top50/top10 n-grams for each (n-1)gram
       }

       ####2.3 Predicting the next word based on the last word

       #####Merge last word with 1gram dictionary

       join_ngramlist <- merge(sentence, dict_1gram, by.x="unigram", by.y="unigram", all.x=TRUE, sort=TRUE)

       if (sum(!is.na(join_ngramlist$freq_2gram)) > 0) {

         #####Calculate which suffix is MLE based on last word

         join_ngramlist$MLE_2gram <- (join_ngramlist$freq_2gram/join_ngramlist$freq_1gram)*rem_pmf_3grams*rem_pmf_2grams
         join_ngramlist$predword_2gram <- word(join_ngramlist$bigram.y,-1)
         unigrampred <- join_ngramlist %>% select(unigram, MLE_2gram, predword_2gram)

       } else {
         unigrampred <- join_ngramlist %>% select(unigram)
         unigrampred$MLE_2gram <- NA
         unigrampred$predword_2gram <- NA
       }

      trigrampred <- merge(trigrampred, bigrampred, by.x="bigram", by.y="bigram")
      trigrampred <- merge(trigrampred, unigrampred, by.x="unigram", by.y="unigram")

      
      ####Determine the backoff MLE as the maximum of the MLE_4gram, MLE_3gram, MLE_2gram. If all three are missing then give an error message.
      
       a <- gather(trigrampred, key=content, value=MLE, c(MLE_4gram, MLE_3gram, MLE_2gram), na.rm=TRUE, factor_key=FALSE) %>% select(content, MLE)
       b <- gather(trigrampred, key=content, value=predword, c(predword_4gram, predword_3gram, predword_2gram), na.rm=TRUE, factor_key=FALSE) %>% select(content, predword)
      
       a$ngram <- substr(a$content,5,9)
       b$ngram <- substr(b$content,10,14)
      
       if (nrow(a) > 0) {
      
         pred_tmp <- cbind(a,b)
         maxMLE=max(pred_tmp$MLE)
         pred_tmp <- pred_tmp[pred_tmp$MLE==maxMLE,c(2,5)] #You still have lots of ties. I keep them all for my prediction
         prediction <- unique(pred_tmp$predword)
      
       } else {
         tmp <- dict_1gram[order(dict_1gram$freq_1gram, decreasing=TRUE),]
         tmp <- tmp[!duplicated(tmp$unigram),]
         prediction <- tmp[1,"unigram"]   #if we didn't observe even the last word, we give the most frequent unigram from our dictionary
         rm(tmp)
       }
       return(prediction)
      
       rm(trigrampred, bigrampred, unigrampred, rem_pmf_2grams, rem_pmf_3grams, join_ngramlist, pred_tmp)
       rm(a, b, maxMLE)

    }

    prediction <- reactive({
      
      clear_text <- str_trim(preprocess_text(which_doc=input$input_sent),side="both")
      
      #Determine the last 3 words, the last 2 words and the last word
      
      words <- str_trim(unlist(strsplit(clear_text," ")), side="both")
      numword <- length(words)

      trigram<- paste(words[numword-2],words[numword-1],words[numword]) 
      bigram <- paste(words[numword-1],words[numword]) 
      unigram <- words[numword]
      inputtext <- cbind(trigram, bigram, unigram)

      #Predict the next word based on Katz-back off estimation model with a discount factor of 0.5 (cross-validated)

      katz_bo_pred(inputtext)
      }) 

    
    output$predicted <- renderTable({
       as.data.frame(prediction())})
    
  })



